
package com.mycompany.mavenproject1;

import java.util.Comparator;

public class OrdenacionProductosDes implements Comparator<String>{

    @Override
    public int compare(String primerObjeto, String segundoObjeto){
    return segundoObjeto.compareTo(primerObjeto);
    }
}

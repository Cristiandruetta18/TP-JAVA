package com.mycompany.mavenproject1;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.TreeMap;

public class Mavenproject1 {

    public static void main(String[] args) {

        HashMap<String, Integer> inventario = new HashMap<>();
        TreeMap<String, Integer> inventarioOrdenado;

        Scanner teclado = new Scanner(System.in);
        teclado.useDelimiter("\n");

        int opcion = 0;

        System.out.println("Inventario de productos");
        System.out.println("-----------------------");

        while (opcion >= 0) {
            System.out.println("\nSeleccione una opcion por favor: ");
            System.out.println("1. Añadir producto");
            System.out.println("2. Aumentar el stock de un producto");
            System.out.println("3. Eliminar el stock de un producto");
            System.out.println("4. Listar productos y su stock");
            System.out.println("5. Eliminar un producto");
            System.out.println("6. Ordenar productos ascendentemente");
            System.out.println("7. Ordenar productos descendentemente");
            System.out.println("8. Salir");

            try {

                System.out.print("Digite una opcion: ");
                opcion = teclado.nextInt();

                String producto;
                int stock, stockActual;

                switch (opcion) {

                    case 1:
                        System.out.print("\nDigite el nombre del producto: ");
                        producto = teclado.next();

                        //si ya existe ese nombre
                        if (inventario.containsKey(producto)) {
                            System.out.println("No se ha podido añadir el producto debido a que ya existe");
                        } else {
                            inventario.put(producto, 0);
                            System.out.println("Se ha añadido el producto");
                        }
                        break;

                    case 2:
                        System.out.print("\nDigite el nombre del producto: ");
                        producto = teclado.next();

                        if (inventario.containsKey(producto)) {
                            System.out.print("\nDigite la cantidad: ");
                            stock = teclado.nextInt();

                            if (stock > 0) {
                                stockActual = inventario.get(producto);
                                inventario.put(producto, stockActual + stock);
                                System.out.println("Se han añadido " + stock + " unidades de stock al producto " + producto + "haciendo un total de" + stockActual + ".");
                            } else {
                                System.out.println("No se puede añadir un stock negativo");
                            }
                        } else {
                            System.out.println("No existe el producto");
                        }
                        break;

                    case 3:
                        System.out.print("\nDigite el nombre del producto: ");
                        producto = teclado.next();

                        if (inventario.containsKey(producto)) {
                            System.out.println("\nDigite el stock a eliminar: ");
                            stock = teclado.nextInt();

                            if (stock > 0) {
                                stockActual = inventario.get(producto);//estoy obteniendo el stock actual

                                if (stockActual > stock) {
                                    inventario.put(producto, stockActual - stock);
                                } else {
                                    System.out.println("No hay suficiente stock a eliminar");
                                }
                            } else {
                                System.out.println("No se puede eliminar un stock negativo");
                            }
                        } else {
                            System.out.println("No existe el producto");
                        }
                        break;

                    case 4:
                        for (String i : inventario.keySet()) {
                            stock = inventario.get(i);
                            System.out.println("");
                            System.out.println("Clave: " + i);
                            System.out.println("Stock: " + stock);
                        }
                        break;

                    case 5:
                        System.out.print("\nDigite el nombre del producto a eliminar: ");
                        producto = teclado.next();

                        if (inventario.containsKey(producto)) {
                            inventario.remove(producto);
                            System.out.println("Producto eliminado");
                        } else {
                            System.out.println("No existe el producto");
                        }
                        break;

                    case 6:
                        inventarioOrdenado = new TreeMap<>(new OrdenacionProductosAsc());
                        inventarioOrdenado.putAll(inventario);

                        for (String i : inventarioOrdenado.keySet()) {
                            stock = inventarioOrdenado.get(i);
                            System.out.println("");
                            System.out.println("Clave: " + i);
                            System.out.println("Stock: " + stock);
                        }
                        break;

                    case 7:
                        inventarioOrdenado = new TreeMap<>(new OrdenacionProductosDes());
                        inventarioOrdenado.putAll(inventario);

                        for (String i : inventarioOrdenado.keySet()) {
                            stock = inventarioOrdenado.get(i);
                            System.out.println("");
                            System.out.println("Clave: " + i);
                            System.out.println("Stock: " + stock);
                        }
                        break;

                    case 8:
                        System.out.println("");
                        System.out.println("Muchas gracias");
                        opcion = 8;
                        break;

                    default:
                        System.out.println("");
                        System.out.println("Vuelva a intentar, esa opcion no esta disponible");
                        break;
                }

            } catch (InputMismatchException exepcion) {
                System.out.println("");
                System.out.println("Vuelva a intentar, solo se permiten números");
                teclado.next();
            }
        }
    }
}

package com.mycompany.mavenproject1;

import java.util.Comparator;

public class OrdenacionProductosAsc implements Comparator<String>{

    @Override
    public int compare(String primerObjeto, String segundoObjeto){
    return primerObjeto.compareTo(segundoObjeto);
    }
}
